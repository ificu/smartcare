
	<div id="popup_period_setting" class="popup_layer">
    	<div id="" class="popup_main">
            <a href="javascript:;" id="" class="xBtn"><img src="img/icon_xBtn.svg" id=""></a>
            <div id="" class="title2">정비주기 설정</div>
            <div id="" class="popup_table">
                <table id="">
                	<tr>
                    	<th id="">⊙ 일반조건</th>
                    	<td id=""><input type="radio" id="일반조건" name="정비주기설정" checked><label for="일반조건">매 7,500 km / 6개월</label></td>
                    </tr>
                    <tr>
                    	<th id="">⊙ 가혹조건</th>
                    	<td id=""><input type="radio" id="가혹조건" name="정비주기설정"><label for="가혹조건">매 7,500 km / 6개월</label></td>
                    </tr>
                    <tr>
                    	<th id="">⊙ 개인 설정조건</th>
                    	<td id=""><input type="radio" id="개인설정조건" name="정비주기설정"><label for="개인설정조건" class="my"><div class="inputBox"><input type="text" id=""></div> km</label></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>