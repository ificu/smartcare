<?php include "head.php"; ?>

	<div class="subArea">
		<div class="titleBox">
        	<a href="javascript:;" class="backBtn"><img src="img/icon_back.svg"></a>
            <div class="title">공지사항</div>
        </div>
        <div class="notice_list">
        	<a href="">신규서비스 안내 (주행 지역 날씨 정보안내)</a>
        	<a href="">안전운전 이벤트 안내 (~'19.12.31까지)</a>
        </div>
    </div>
    
</div> <!-- // wraper-->

</body>
</html>