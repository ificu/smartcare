    <footer>
        <div class="info">
            ㈜피디엠 <a href="javascript:;">사업자정보</a><br>
            고객센터 0000-0000 (평일 09:00~18:00 주말/공휴일 휴무)<br>
            Copyright PDM lnc. All Right Reserved.
        </div>
    </footer>

</div> <!-- // wraper-->

</body>
</html>