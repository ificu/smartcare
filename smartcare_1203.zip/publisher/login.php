<?php include "head.php"; ?>
   
	<div id="login">
		<img src="img/logo_login.svg" class="logo">
        <div class="title">Smart Care</div>
        <div class="subTitle">(BETA)</div>
        <img src="img/login_img.svg" class="login_img">
        <div class="text">
        	고객님의 <span>안전</span>을 최우선으로<br>
			고객님의 안전이 곧 <span>가족의 행복</span>
        </div>
        <div class="formBox">
        	<div class="inputBox"><p class="iconBox icon01"></p><input type="text" placeholder="USERNAME"></div>
            <div class="inputBox"><p class="iconBox icon02"></p><input type="password" placeholder="PASSWORD"></div>
            <a href="javascript:;" class="btn">LOGIN</a>
        </div>
        <div class="bottom_text">궁금하신 내용용이나 로그인 문제시,<br>스마트링크 고객센터 (1800-2023)<br>혹은 canadajw@sk.com으로 연락주시기 바랍니다.</div>
    </div>
    
</div> <!-- // wraper-->

</body>
</html>