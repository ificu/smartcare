<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=0,maximum-scale=10,user-scalable=yes">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.4.2/js/swiper.min.js"></script>
<link rel="stylesheet" href="css/style.css?<?=date('YmdHis');?>">
<link rel="stylesheet" href="css/swiper.min.css">
<title>SMART CARE</title>

</head>

<script>
function layer_open(el){
	var temp = $('#' + el);
	temp.fadeIn();

	temp.find('.xBtn').click(function(e){
		temp.fadeOut();
		e.preventDefault();
	});
}
</script>

<body>

<div id="wraper">
	
