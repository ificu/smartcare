export default {
    LAMBDA_URL: 'https://rmv9oaohn6.execute-api.ap-northeast-2.amazonaws.com/prod/smartcare',
    LAMBDA_HEADER: {'Accept': 'application/json','Content-Type': 'application/json','x-api-key': 'kJNQhxA0Z94P903AjNTd93CB91TlZjLL8NvSF3Ra'}
  };
