
	<div id="popup_01" class="popup_layer">
    	<div class="popup_main">
            <img src="img/icon_comingsoon.svg" class="comingsoon">
            <a href="javascript:;" class="xBtn"><img src="img/icon_xBtn.svg"></a>
            <div class="title">119 자동출동 서비스</div>
            <div class="textBox">
                <span>Smart Care</span> 를 통한 긴급<br>
                자동 119 자동출동 호출 서비스
            </div>
            <div class="subText">
                긴급 혹은 대형사고로 판단될 경우,<br>
                사고발생 위치로 119 출동 요청 드리는 서비스입니다.<br>
                (고객님께 선연락 후 통화가 되지 않을 시 진행)<br><br>
                
                SK 렌터카 차량을 이용하는 본인 뿐 아니라<br>
                차량을 같이 이용하는 배 우자, 부모님, 자녀 등<br>
                운전 고객의 안전을 위한 서비스 입니다.
            </div>
        </div>
    </div>